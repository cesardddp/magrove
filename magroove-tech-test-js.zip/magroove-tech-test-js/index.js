class ToDoItem extends React.Component {
	constructor(props) {
		super(props);
		this.state = {is_done: false};
	}

	render() {
		return (
			<li>
				{this.props.task}
			</li>
		);
	}
}	

class ToDoList extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			to_do_list: ['Finish this test', 'Get hired', 'Change the world']
		};
	}

	render() {
		return (
			<div>
				<h2>Add a new task to your to-do list</h2>
				<input type="text" />
				<button>Add</button>
				<ul>
					{this.state.to_do_list.map((task_text) =>
						<ToDoItem task={task_text} />
					)}
				</ul>
			</div>
		);
	}
}

ReactDOM.render(
	<ToDoList/>,
	document.getElementById('root')
);